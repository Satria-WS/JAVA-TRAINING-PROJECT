package com.sebatSamsu.backend.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullstackBackendSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(FullstackBackendSpringApplication.class, args);
	}

}
